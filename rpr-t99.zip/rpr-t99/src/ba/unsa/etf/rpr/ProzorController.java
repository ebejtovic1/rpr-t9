package ba.unsa.etf.rpr;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class ProzorController {
    private static GeografijaDAO baza = null;
    public Button izmjeniDrzavuButton;
    public Button dodajDrzavuButton;
    public Button izmjeniGradButton;
    public Button dodajGradButton;
    public TableView<Drzava> tabelaDrzava;
    public TableView<Grad> tabelaGradova;
    public TextField prvoPolje;
    public TextField drugoPolje;
    public TextField trecePolje;
    public TextField cetvrtoPolje;
    public Button clearButton;
    public Button obrisiDrzavuButton;
    public Button obrisiGradButton;
    public Button refreshButton;
    private DrzavaModel modelDrzava;
    private GradModel modelGradova;

    public TableColumn<Drzava, Integer> idDrzavaKolona;
    public TableColumn<Drzava, String> nazivDrzaveKolona;
    public TableColumn<Drzava, Grad> glavniGradKolona;

    public TableColumn<Grad, Integer> idGradKolona;
    public TableColumn<Grad, String> nazivGradKolona;
    public TableColumn<Grad, Integer> brojStanovnikaKolona;
    public TableColumn<Grad, Drzava> drzavaIdKolona;

    public ProzorController(GeografijaDAO baza, DrzavaModel drzavaModel, GradModel gradModel) {
        ProzorController.baza = baza;
        modelDrzava = drzavaModel;
        modelGradova = gradModel;
    }

    @FXML
    public void initialize() {
        prvoPolje.setDisable(true);
        clearButtonClick(null);
        tabelaDrzava.setItems(modelDrzava.getDrzave());
        tabelaGradova.setItems(modelGradova.getGradovi());

        //Postavljanje selektovane drzave za trenutnu drzavu
        tabelaDrzava.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                tabelaGradova.getSelectionModel().clearSelection();
                dodajDrzavuButton.setDisable(true);
                dodajGradButton.setDisable(true);
                izmjeniGradButton.setDisable(true);
                izmjeniDrzavuButton.setDisable(false);
                cetvrtoPolje.setDisable(true);
                modelDrzava.setTrenutnaDrzava(newValue);
                prvoPolje.setText(String.valueOf(newValue.getIdDrzava()));
                drugoPolje.setText(newValue.getNazivDrzave());
                trecePolje.setText(String.valueOf(newValue.getGlavniGrad().getIdGrad()));
            }
        });

        // Detektovanje dvostrukog klika za drzavu
        tabelaDrzava.setRowFactory(tv -> {
            TableRow<Drzava> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && (!row.isEmpty())) {
                    izmjeniDrzavuClick(null);
                }
            });
            return row;
        });

        //Postavljanje selektovanog grada za trenutni grad
        tabelaGradova.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                tabelaDrzava.getSelectionModel().clearSelection();
                dodajDrzavuButton.setDisable(true);
                dodajGradButton.setDisable(true);
                izmjeniDrzavuButton.setDisable(true);
                izmjeniGradButton.setDisable(false);
                cetvrtoPolje.setDisable(false);
                modelGradova.setTrenutniGrad(newValue);
                prvoPolje.setText(String.valueOf(newValue.getIdGrad()));
                drugoPolje.setText(newValue.getNazivGrad());
                trecePolje.setText(String.valueOf(newValue.getBrojStanovnika()));
                cetvrtoPolje.setText(String.valueOf(newValue.getDrzava().getIdDrzava()));
            }
        });

        // Detektovanje dvostrukog klika za grad
        tabelaGradova.setRowFactory(tv -> {
            TableRow<Grad> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && (!row.isEmpty())) {
                    izmjeniGradClick(null);
                }
            });
            return row;
        });

        idDrzavaKolona.setCellValueFactory(new PropertyValueFactory<>("idDrzava"));
        nazivDrzaveKolona.setCellValueFactory(new PropertyValueFactory<>("nazivDrzave"));
        glavniGradKolona.setCellValueFactory(new PropertyValueFactory<>("glavniGrad"));

        idGradKolona.setCellValueFactory(new PropertyValueFactory<>("idGrad"));
        nazivGradKolona.setCellValueFactory(new PropertyValueFactory<>("nazivGrad"));
        brojStanovnikaKolona.setCellValueFactory(new PropertyValueFactory<>("brojStanovnika"));
        drzavaIdKolona.setCellValueFactory(new PropertyValueFactory<>("drzava"));
    }

    private void prikaziAlert(String title, String headerText) {
        Alert error = new Alert(Alert.AlertType.INFORMATION);
        error.setTitle(title);
        error.setHeaderText(headerText);
        error.show();
    }

    public void izmjeniDrzavuClick(ActionEvent actionEvent) {
        if (modelDrzava.getTrenutnaDrzava() == null)
            return;
        if (cetvrtoPolje.isDisabled()) {
            int id = Integer.parseInt(prvoPolje.getText());
            String naziv = drugoPolje.getText();
            int glavniGradId = Integer.parseInt(trecePolje.getText());
            baza.izmijeniDrzava(new Drzava(id, naziv, new Grad(glavniGradId, "", 0, null)));
            prikaziAlert("Uspjeh", "Uspjesno izmjenjena drzava");
        }
    }

    public void dodajDrzavuClick(ActionEvent actionEvent) {
        if (drugoPolje.getText().isEmpty() || cetvrtoPolje.getText().isEmpty())
            return;
        String naziv = drugoPolje.getText();
        String nazivGrada = cetvrtoPolje.getText();
        baza.dodajDrzavu(new Drzava(0, naziv, new Grad(0, nazivGrada, 0, null)));
        prikaziAlert("Uspjeh", "Uspjesno dodata drzava");
    }

    public void izmjeniGradClick(ActionEvent actionEvent) {
        if (modelGradova.getTrenutniGrad() == null)
            return;
        if (!cetvrtoPolje.isDisabled()) {
            int id = Integer.parseInt(prvoPolje.getText());
            String naziv = drugoPolje.getText();
            int brojStanovnika = Integer.parseInt(trecePolje.getText());
            int drzavaId = Integer.parseInt(cetvrtoPolje.getText());
            baza.izmijeniGrad(new Grad(id, naziv, brojStanovnika, new Drzava(drzavaId, "", null)));
            prikaziAlert("Uspjeh", "Uspjesno izmjenjen grad");
        }
    }

    public void dodajGradClick(ActionEvent actionEvent) {
        if (drugoPolje.getText().isEmpty() || cetvrtoPolje.getText().isEmpty())
            return;
        String naziv = drugoPolje.getText();
        int brojStanovnika = Integer.parseInt(trecePolje.getText());
        String drzavaNaziv = cetvrtoPolje.getText();
        baza.dodajGrad(new Grad(0, naziv, brojStanovnika, new Drzava(0, drzavaNaziv, null)));
        prikaziAlert("Uspjeh", "Uspjesno dodat grad");
    }

    public void clearButtonClick(ActionEvent actionEvent) {
        prvoPolje.clear();
        drugoPolje.clear();
        trecePolje.clear();
        cetvrtoPolje.clear();
        cetvrtoPolje.setDisable(false);
        izmjeniGradButton.setDisable(true);
        izmjeniDrzavuButton.setDisable(true);
        dodajDrzavuButton.setDisable(false);
        dodajGradButton.setDisable(false);
        tabelaDrzava.getSelectionModel().clearSelection();
        tabelaGradova.getSelectionModel().clearSelection();
        prvoPolje.setPromptText("Id");
        drugoPolje.setPromptText("Naziv");
        trecePolje.setPromptText("Broj stanovnika (grad)");
        cetvrtoPolje.setPromptText("Naziv grada / Naziv drzave");
    }

    public void obrisiGradClick(ActionEvent actionEvent) {
        if (modelGradova.getTrenutniGrad() == null)
            return;
        baza.obrisiGrad(modelGradova.getTrenutniGrad().getNazivGrad());
        prikaziAlert("Uspjeh", "Uspjesno izbrisan grad");
    }

    public void obrisiDrzavuClick(ActionEvent actionEvent) {
        if (modelDrzava.getTrenutnaDrzava() == null)
            return;
        baza.obrisiDrzavu(modelDrzava.getTrenutnaDrzava().getNazivDrzave());
        prikaziAlert("Uspjeh", "Uspjesno izbrisana drzava");
    }

    public void refreshClick(ActionEvent actionEvent) {
        modelDrzava.refresh(baza);
        modelGradova.refresh(baza);
    }
}
